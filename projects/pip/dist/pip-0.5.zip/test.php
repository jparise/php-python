<?php

$a = "test";
$b = true;
$c = 50;
$d = 60.4;

$code = <<<EOD
import php

a = php.var('a')
b = php.var('b')
c = php.var('c')
d = php.var('d')

print a, b, c, d
print a, d / c + b, a
EOD;

$code = str_replace("\r\n", "\n", $code);

py_eval($code);

$p = new Python('module', 'TestClass', array(435));
print $p->returnInt() . "\n";
print $p->test(1, 'bar') . "\n";

print $p->foo . "\n";
$p->foo = 987;
print $p->foo . "\n";

# $copy points to the same object
$copy = $p->returnMe();
print $copy->foo . "\n";
$p->foo = 987;
print $copy->foo . "\n";

var_dump($p->returnTuple());
var_dump($p->returnList());
var_dump($p->returnDict());

$a = array('one' => 1, 2, 3);
$p->p($a);

class Test {
	var $member = 'test';
}

$t = new Test();
$p->p($t);

?>
